import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput, Button, KeyboardAvoidingView, FlatList, Image } from 'react-native';
import DateTimePicker from '@react-native-community/datetimepicker';
import { Picker } from '@react-native-picker/picker';
import axios from 'axios';

const AdminDashboard = () => {

  const [activeTab, setActiveTab] = useState('dashboard');
  const [schedules, setSchedules] = useState([]);
  const [reports, setReports] = useState([]);

  // Handle tab switch
  const handleTabChange = (tab) => setActiveTab(tab);

  const [newEmployee, setNewEmployee] = useState({
    name: '',
    role: '',
    office: '',
    department: '',
    username: '',
    password: ''
  });
  const [employees, setEmployees] = useState([]);

  // Fetch Employees from API
  const fetchEmployees = async () => {
    try {
      const response = await fetch('http://localhost:5000/api/admin/employees');
      const data = await response.json();
      setEmployees(data);
    } catch (error) {
      console.error('Error fetching employees:', error);
    }
  };

  // POST Employee to Employee API
  const handleAddEmployee = async () => {
    try {
      // Step 1: Create the employee first
      const employeeResponse = await fetch('http://localhost:5000/api/admin/employees', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          name: newEmployee.name,
          role: newEmployee.role,
          office: newEmployee.office,
          department: newEmployee.department
        }),
      });

      if (employeeResponse.ok) {
        const createdEmployee = await employeeResponse.json();  // Get the created employee details, including _id

        // Step 2: Use the employee _id to create the login entry
        const loginResponse = await fetch('http://localhost:5000/api/signup', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            username: newEmployee.username,
            password: newEmployee.password,
            role: "employee",
            employeeId: createdEmployee._id  // Pass the employee _id to link employee and user
          }),
        });

        if (loginResponse.ok) {
          // Step 3: Reset the input fields and fetch the employee list after successful submission
          setNewEmployee({
            name: '',
            role: '',
            office: '',
            department: '',
            username: '',
            password: ''
          });
          fetchEmployees(); // Refresh the employee list
        } else {
          console.error('Error adding login details:', loginResponse.status);
        }
      } else {
        console.error('Error adding employee:', employeeResponse.status);
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };


  // Fetch employees, offices, and departments on component mount
  useEffect(() => {
    fetchEmployees();
  }, []);

  //Add Reports
  const fetchReports = async () => {
    try {
      const response = await fetch('https://employee-nine-theta.vercel.app/api/admin/reports'); // Adjust the URL as necessary
      if (!response.ok) {
        throw new Error('Failed to fetch reports');
      }
      const data = await response.json();
      setReports(data);
    } catch (error) {
      Alert.alert('Error', error.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchReports();
  }, []);

  // Render Report Items
  const renderReport = ({ item }) => (
    <View style={styles.listItem}>
      <Text>{item.name}</Text>
      <Text>Hours Worked: {item.totalHoursWorked.toFixed(2)} hours</Text>
    </View>
  );
  // Add Schdules Details
  const [newSchedule, setNewSchedule] = useState({
    employee: '',
    start: '',  // Manual input for time in 'HH:mm' format
    end: '',    // Manual input for time in 'HH:mm' format
  });

  const fetchSchedules = async () => {
    try {
      const response = await fetch('https://employee-nine-theta.vercel.app/api/admin/get-schedules');
      const data = await response.json();
      setSchedules(data);

    } catch (error) {
      console.error('Error fetching schedules:', error);
    }
  };

  const [isStartPickerVisible, setStartPickerVisible] = useState(false); // Modal visibility for start time
  const [isEndPickerVisible, setEndPickerVisible] = useState(false);

  // Validate time format (optional)
  const isValidTime = (time) => {
    const timeRegex = /^([0-1][0-9]|2[0-3]):([0-5][0-9])$/;
    return timeRegex.test(time);
  };

  const handleTimeChange = (event, selectedTime, field) => {
    if (selectedTime) {
      const hours = selectedTime.getHours().toString().padStart(2, '0'); // Ensure two digits for hours
      const minutes = selectedTime.getMinutes().toString().padStart(2, '0'); // Ensure two digits for minutes
      const formattedTime = `${hours}:${minutes}`;

      setNewSchedule({ ...newSchedule, [field]: formattedTime });

      // Hide the picker modals after time selection
      if (field === 'start') setStartPickerVisible(false);
      if (field === 'end') setEndPickerVisible(false);
    }
  };

  const handleAddSchedule = async () => {
    try {
      const response = await fetch('https://employee-nine-theta.vercel.app/api/admin/add-schedule', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(newSchedule),
      });

      if (response.ok) {
        setNewSchedule({ employee: '', start: '', end: '' });
        fetchSchedules();  // Refresh the schedule list
      } else {
        console.error('Error adding schedule:', response.status);
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };

  useEffect(() => {
    fetchEmployees();
    fetchSchedules();
  }, []);

  //Setting Section Api
  const [newOffice, setNewOffice] = useState('');
  const [offices, setOffices] = useState([]);
  const [newDepartment, setNewDepartment] = useState('');
  const [departments, setDepartments] = useState([]);

  // Get Offices from API
  const fetchOffices = async () => {
    try {
      const response = await fetch('https://employee-nine-theta.vercel.app/api/admin/offices');
      const data = await response.json();
      setOffices(data);
    } catch (error) {
      console.error('Error fetching offices:', error);
    }
  };

  // Get Departments from API
  const fetchDepartments = async () => {
    try {
      const response = await fetch('https://employee-nine-theta.vercel.app/api/admin/departments');
      const data = await response.json();
      setDepartments(data);
    } catch (error) {
      console.error('Error fetching departments:', error);
    }
  };

  // POST Office to API
  const handleAddOffice = async () => {
    try {
      const response = await fetch('https://employee-nine-theta.vercel.app/api/admin/offices', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ name: newOffice }),
      });
      if (response.ok) {
        setNewOffice(''); // Clear input
        fetchOffices();   // Fetch updated list
      }
    } catch (error) {
      console.error('Error adding office:', error);
    }
  };

  // POST Department to API
  const handleAddDepartment = async () => {
    try {
      const response = await fetch('https://employee-nine-theta.vercel.app/api/admin/departments', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ name: newDepartment }),
      });
      if (response.ok) {
        setNewDepartment(''); // Clear input
        fetchDepartments();   // Fetch updated list
      }
    } catch (error) {
      console.error('Error adding department:', error);
    }
  };

  useEffect(() => {
    fetchOffices();
    fetchDepartments();
  }, []);

  const [pendingRequests, setPendingRequests] = useState([]);

  useEffect(() => {
    axios.get('https://employee-nine-theta.vercel.app/api/admin/pendingRequests')
      .then(response => setPendingRequests(response.data))
      .catch(error => console.error('Error fetching pending requests:', error));
  }, []);

  const handleRequestUpdate = (requestId, status) => {
    axios.put(`https://employee-nine-theta.vercel.app/api/admin/updateRequest/${requestId}`, { status })
      .then(() => {
        setPendingRequests(pendingRequests.filter(request => request._id !== requestId));
      })
      .catch(error => console.error('Error updating request status:', error));
  };

  const renderRequest = ({ item }) => (
    <View style={{ padding: 10 }}>
      <Text>Employee: {item.employeeId.name}</Text>
      <Text>Reason: {item.reason}</Text>
      <Text>Start Date: {new Date(item.startDate).toLocaleDateString()}</Text>
      <Text>End Date: {new Date(item.endDate).toLocaleDateString()}</Text>
      <View style={{ flex: 1, flexDirection: 'row', gap: 10 }}>
        <Button title="Approve" onPress={() => handleRequestUpdate(item._id, 'Approved')} />
        <Button title="Reject" onPress={() => handleRequestUpdate(item._id, 'Rejected')} />
      </View>
    </View>
  );

  return (

    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerText}>Admin Dashboard</Text>
      </View>
      <View style={styles.scrollableContent}>
        {/* Main Content */}
        <ScrollView
          contentContainerStyle={styles.scrollViewContent}
          keyboardShouldPersistTaps="handled"

        >
          {/* Dashboard */}
          {activeTab === 'dashboard' && (
            <View style={styles.tabContent}>
              <Text style={styles.sectionTitle}>Dashboard</Text>
              <View style={styles.statsContainer}>
                <View style={styles.statBox}>
                  <Text>Total Employees</Text>
                  <Text style={styles.statNumber}>{employees.length}</Text>
                </View>
                <View style={styles.statBox}>
                  <Text>Total Offices</Text>
                  <Text style={styles.statNumber}>{offices.length}</Text>
                </View>
                <View style={styles.statBox}>
                  <Text>Total Departments</Text>
                  <Text style={styles.statNumber}>{departments.length}</Text>
                </View>
              </View>
              <View>
                <Text style={{ margin: "auto" }}>Time Off Requests</Text>
                {pendingRequests.length > 0 ? (
                  <FlatList
                    data={pendingRequests}
                    renderItem={renderRequest}
                    keyExtractor={item => item._id}
                  />
                ) : (
                  <Text style={{
                    textAlign: 'center', marginTop: 20, fontSize: 20,
                    fontWeight: 'bold'
                  }}>0</Text>
                )}
              </View>
            </View>

          )}

          {/* Manage Employees */}
          {activeTab === 'employees' && (
            <View style={styles.tabContent}>
              <Text style={styles.sectionTitle}>Manage Employees</Text>

              <TextInput
                placeholder="Employee Name"
                value={newEmployee.name}
                onChangeText={(text) => setNewEmployee({ ...newEmployee, name: text })}
                style={styles.input}
              />
              <TextInput
                placeholder="Role"
                value={newEmployee.role}
                onChangeText={(text) => setNewEmployee({ ...newEmployee, role: text })}
                style={styles.input}
              />

              <TextInput
                placeholder="Username"
                value={newEmployee.username}
                onChangeText={(text) => setNewEmployee({ ...newEmployee, username: text })}
                style={styles.input}
              />
              <TextInput
                placeholder="Password"
                value={newEmployee.password}
                onChangeText={(text) => setNewEmployee({ ...newEmployee, password: text })}
                secureTextEntry={true}
                style={styles.input}
              />
              {/* Office Picker */}
              <Picker
                selectedValue={newEmployee.office}
                onValueChange={(value) => setNewEmployee({ ...newEmployee, office: value })}
                style={styles.picker}
              >
                <Picker.Item label="Select Office" value="" />
                {offices.map((office, index) => (
                  <Picker.Item key={index} label={office.name} value={office.name} />
                ))}
              </Picker>

              {/* Department Picker */}
              <Picker
                selectedValue={newEmployee.department}
                onValueChange={(value) => setNewEmployee({ ...newEmployee, department: value })}
                style={styles.picker}
              >
                <Picker.Item label="Select Department" value="" />
                {departments.map((department, index) => (
                  <Picker.Item key={index} label={department.name} value={department.name} />
                ))}
              </Picker>

              <Button title="Add Employee" onPress={handleAddEmployee} />

              {/* Display Employees List */}
              <FlatList
                data={employees}
                keyExtractor={(item) => item.id}
                renderItem={({ item }) => (
                  <View style={styles.listItem}>
                    <Text>Name: {item.name}</Text>
                    <Text>Role: {item.role}</Text>
                    <Text>Office: {item.office}</Text>
                    <Text>Department: {item.department}</Text>
                  </View>
                )}
              />
            </View>
          )}

          {/* Schedule Management */}
          {activeTab === 'schedules' && (
            <View style={styles.tabContent}>
              <Text style={styles.sectionTitle}>Manage Schedules</Text>

              {/* Employee Picker */}
              <Picker
                selectedValue={newSchedule.employee}
                onValueChange={(value) => setNewSchedule({ ...newSchedule, employee: value })}
                style={styles.picker}>
                <Picker.Item label="Select Employee" value="" />
                {employees.map((employee) => (
                  <Picker.Item key={employee._id} label={employee.name} value={employee._id} />
                ))}
              </Picker>

              {/* Shift Start Time Input */}
              <TouchableOpacity onPress={() => setStartPickerVisible(true)}>
                <TextInput
                  placeholder="Shift Start (HH:mm)"
                  value={newSchedule.start}
                  editable={false} // Disable manual typing
                  style={styles.input}
                />
              </TouchableOpacity>

              {/* Shift End Time Input */}
              <TouchableOpacity onPress={() => setEndPickerVisible(true)}>
                <TextInput
                  placeholder="Shift End (HH:mm)"
                  value={newSchedule.end}
                  editable={false} // Disable manual typing
                  style={styles.input}
                />
              </TouchableOpacity>

              <Button title="Add Schedule" onPress={handleAddSchedule} />

              {/* List of Schedules */}
              <FlatList
                data={schedules}
                keyExtractor={(item) => item.id}
                renderItem={({ item }) => (
                  <View style={styles.listItem}>
                    <Text>Employee: {item.employee.name}</Text>
                    <Text>Start: {item.start}</Text>
                    <Text>End: {item.end}</Text>
                  </View>
                )
                }
              />

              {/* Start Time Picker Modal */}
              {isStartPickerVisible && (
                <DateTimePicker
                  mode="time"
                  value={new Date()}
                  is24Hour={false}
                  display="default"
                  onChange={(event, selectedTime) => handleTimeChange(event, selectedTime, 'start')}
                />
              )}

              {/* End Time Picker Modal */}
              {isEndPickerVisible && (
                <DateTimePicker
                  mode="time"
                  value={new Date()}
                  is24Hour={false}
                  display="default"
                  onChange={(event, selectedTime) => handleTimeChange(event, selectedTime, 'end')}
                />
              )}
            </View>
          )}

          {/* Reports Management */}
          {activeTab === 'reports' && (
            <View style={styles.tabContent}>
              <Text style={styles.sectionTitle}>Reports</Text>
              <FlatList
                data={reports}
                keyExtractor={(item, index) => index.toString()}
                renderItem={renderReport}
              />
            </View>
          )}

          {/* Settings */}
          {activeTab === 'settings' && (
            <View style={styles.tabContent}>
              <Text style={styles.sectionTitle}>Settings - Offices</Text>
              <TextInput
                placeholder="New Office"
                value={newOffice}
                onChangeText={setNewOffice}
                style={styles.input}
              />
              <Button title="Add Office" onPress={handleAddOffice} />
              <FlatList
                data={offices}
                keyExtractor={(item, index) => index.toString()}
                renderItem={({ item }) => <Text style={styles.listItem}>{item.name}</Text>}
              />

              <Text style={styles.sectionTitle}>Settings - Departments</Text>
              <TextInput
                placeholder="New Department"
                value={newDepartment}
                onChangeText={setNewDepartment}
                style={styles.input}
              />
              <Button title="Add Department" onPress={handleAddDepartment} />
              <FlatList
                data={departments}
                keyExtractor={(item, index) => index.toString()}
                renderItem={({ item }) => <Text style={styles.listItem}>{item.name}</Text>}
              />
            </View>
          )}
        </ScrollView>
      </View>

      {/* Footer Navigation */}
      <View style={styles.footer}>
        <TouchableOpacity onPress={() => handleTabChange('dashboard')} style={styles.footerButton}>
          <Image
            source={require('../images/dashboard.png')}
            style={[styles.icon, { tintColor: activeTab === 'dashboard' ? '#1a73e8' : '#fff' }]}
          />
          <Text style={[styles.footerText, activeTab === 'dashboard' && styles.activeFooterText]}>Dashboard</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => handleTabChange('employees')} style={styles.footerButton}>
          <Image source={require('../images/employee-line.png')}
            style={[styles.icon, { tintColor: activeTab === 'employees' ? '#1a73e8' : '#fff' }]} />
          <Text style={[styles.footerText, activeTab === 'employees' && styles.activeFooterText]}>Employees</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => handleTabChange('schedules')} style={styles.footerButton}>
          <Image source={require('../images/roadmap.png')}
            style={[styles.icon, { tintColor: activeTab === 'schedules' ? '#1a73e8' : '#fff' }]} />
          <Text style={[styles.footerText, activeTab === 'schedules' && styles.activeFooterText]}>Schedules</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => handleTabChange('reports')} style={styles.footerButton}>
          <Image source={require('../images/reports.png')}
            style={[styles.icon, { tintColor: activeTab === 'reports' ? '#1a73e8' : '#fff' }]}
          />
          <Text style={[styles.footerText, activeTab === 'reports' && styles.activeFooterText]}>Reports</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => handleTabChange('settings')} style={styles.footerButton}>
          <Image source={require('../images/settings.png')}
            style={[styles.icon, { tintColor: activeTab === 'settings' ? '#1a73e8' : '#fff' }]} />
          <Text style={[styles.footerText, activeTab === 'settings' && styles.activeFooterText]}>Settings</Text>
        </TouchableOpacity>
      </View>
    </View>

  );
};


const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    backgroundColor: '#1a73e8',
    padding: 15,
    width: '100%',
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 1,
  },
  headerText: {
    color: '#fff',
    fontSize: 18,
    textAlign: 'center',
  },
  scrollableContent: {
    flex: 1,
    marginTop: 60, // Adjust to match header height
    marginBottom: 60, // Adjust to match footer height
  },
  scrollViewContent: {
    padding: 15,
  },

  tabContent: {
    padding: 5,
  },
  sectionTitle: {
    fontSize: 20,
    marginBottom: 10,
  },
  statsContainer: {
    justifyContent: 'space-around',
  },
  statBox: {
    backgroundColor: '#f1f3f4',
    padding: 15,
    borderRadius: 8,
    width: '100%',
    alignItems: 'center',
    marginBottom: 10,
  },
  statNumber: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    padding: 5,
    marginBottom: 10,
  },
  picker: {
    marginBottom: 5,
  },
  listItem: {
    padding: 10,
    backgroundColor: '#f1f3f4',
    borderRadius: 5,
  },
  footer: {
    flexDirection: 'row',
    backgroundColor: '#2b3e50',
    justifyContent: 'space-around',
    paddingVertical: 10,
    position: 'absolute',
    bottom: 0,
    width: '100%',
  },
  footerButton: {
    alignItems: 'center',
  },
  footerText: {
    color: '#fff',
    marginTop: 5,
  },
  activeFooterText: {
    color: '#1a73e8',
  },
  icon: {
    height: 25,
    width: 25,
  }
});

export default AdminDashboard;
