import React, { useState, useEffect } from 'react';
import {
  SafeAreaView,
  View,
  Text,
  TouchableOpacity,
  Button,
  TextInput,
  StyleSheet,
  ScrollView,
  Alert,
  FlatList,
  PermissionsAndroid,
  Platform
} from 'react-native';
import DateTimePicker from '@react-native-community/datetimepicker';
import Geolocation from 'react-native-geolocation-service';
import axios from 'axios';
import ImagePicker from 'react-native-image-picker';

const EmployeeDashboard = ({ route }) => {
  const { user } = route.params;

  // State variables
  const [activeTab, setActiveTab] = useState('currentShift');
  const [employeeSch, setEmployeeSch] = useState([]);
  const [isClockedIn, setIsClockedIn] = useState(false);
  const [clockInTime, setClockInTime] = useState(null);
  const [totalHours, setTotalHours] = useState(0);
  const [timeSinceClockIn, setTimeSinceClockIn] = useState('0');
  const [startDate, setStartDate] = useState(new Date()); // Ensure Date is initialized
  const [endDate, setEndDate] = useState(new Date());
  const [reason, setReason] = useState('');
  const employeeId = user.id;
  const [selfieUri, setSelfieUri] = useState(null);

  const requestLocationPermission = async () => {
    if (Platform.OS === 'android') {
      try {
        const granted = await PermissionsAndroid.request(
          PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
          {
            title: 'Location Permission',
            message: 'We need access to your location to track your clock-in position.',
            buttonNeutral: 'Ask Me Later',
            buttonNegative: 'Cancel',
            buttonPositive: 'OK',
          }
        );
        if (granted === PermissionsAndroid.RESULTS.GRANTED) {
          console.log('Location permission granted');
          return true;
        } else {
          console.log('Location permission denied');
          return false;
        }
      } catch (err) {
        console.warn(err);
        return false;
      }
    } else {
      // For iOS, we don't need explicit permission request, the system handles it
      return true;
    }
  };

  const getIpAddress = async () => {
    try {
      const response = await axios.get('https://api.ipify.org?format=json');
      return response.data.ip; // IP address in the form of a string
    } catch (error) {
      console.error('Error fetching IP address:', error);
      return null; // Return null if the IP address can't be fetched
    }
  };

  const getGeolocation = async () => {
    try {
      // Check if permission is granted before getting location
      const permissionGranted = await requestLocationPermission(); // Await the permission request

      if (!permissionGranted) {
        throw new Error('Location permission not granted');
      }

      // Now get the current position
      return new Promise((resolve, reject) => {
        Geolocation.getCurrentPosition(
          position => {
            resolve(position.coords); // Return the latitude and longitude
          },
          error => {
            reject(error.message); // If there's an error, reject the promise
          },
          { enableHighAccuracy: true, timeout: 15000, maximumAge: 10000 }
        );
      });
    } catch (error) {
      return Promise.reject(error.message); // Reject the promise with the error message
    }
  };

  const handleTakeSelfie = () => {
    // Open the image picker to take a selfie
    ImagePicker.launchCamera(
      {
        mediaType: 'photo',
        quality: 0.8,
        cameraType: 'front', // Use front camera for selfie
      },
      response => {
        if (response.didCancel) {
          Alert.alert('Error', 'Selfie is required to clock in.');
        } else if (response.errorMessage) {
          Alert.alert('Error', response.errorMessage);
        } else {
          // Set the selfie URI if the user successfully took a selfie
          setSelfieUri(response.uri);
        }
      }
    );
  };


  const handleClockIn = async () => {

    if (!selfieUri) {
      // If no selfie is taken, prompt the user to take one
      Alert.alert('Required', 'Please take a selfie to clock in.');
      handleTakeSelfie();
      return;
    }

    const ipAddress = await getIpAddress();
    const geolocation = await getGeolocation();
    try {
      const response = await axios.post('http://localhost:5000/api/employee/clockin', {
        employeeId,
        ipAddress,
        location: {
          latitude: geolocation.latitude,
          longitude: geolocation.longitude,
        },
        selfie: {
          uri: selfieUri, // Send the selfie URI
        }
      });

      if (response.data) {
        setIsClockedIn(true);
        setClockInTime(new Date()); // Record the current time as clock-in time
        Alert.alert('Success', 'Clocked in successfully!');
      }
    } catch (error) {
      const errorMessage = error.response?.data?.error || error.message;
      Alert.alert('Error', errorMessage);
    }
  };

  // Function to handle clock-out
  const handleClockOut = async () => {
    try {
      const response = await axios.post('http://localhost:5000/api/employee/clockout', {
        employeeId,
      });

      if (response.data) {
        setIsClockedIn(false);

        const hoursWorked = response.data.hoursWorked;

        // Check if hoursWorked is defined before calling .toFixed()
        if (typeof hoursWorked !== 'undefined') {
          setTotalHours(totalHours + hoursWorked); // Update total hours worked
          Alert.alert('Success', `Clocked out successfully. Hours worked: ${hoursWorked.toFixed(2)}`);
        } else {
          // Handle the case where hoursWorked is not returned
          Alert.alert('Error', 'Hours worked is undefined');
        }

        setClockInTime(null); // Reset clock-in time
      }
    } catch (error) {
      const errorMessage = error.response?.data?.error || error.message;
      Alert.alert('Error', errorMessage);
    }
  };

  // Effect to update time since clock-in every minute
  useEffect(() => {
    if (isClockedIn && clockInTime) {
      const interval = setInterval(() => {
        const now = new Date();
        const elapsedMilliseconds = now - clockInTime;
        const elapsedHours = (elapsedMilliseconds / 1000 / 60 / 60).toFixed(2);
        setTimeSinceClockIn(`${elapsedHours} hours`);
      }, 10000); // Update every minute

      return () => clearInterval(interval);
    }
  }, [isClockedIn, clockInTime]);


  const getEmployeeSchedules = async () => {
    try {
      const response = await fetch(`https://employee-nine-theta.vercel.app/api/admin/get-schedules`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        throw new Error('Network response was not ok');
      }

      const data = await response.json();  // Parse the JSON response
      const filteredSchedules = data.filter(schedule => schedule.employee._id === user.id);
      setEmployeeSch(filteredSchedules)
    } catch (error) {
      console.error('Error fetching employee schedules:', error);
      Alert.alert('Error', 'Could not fetch schedules');
    }
  };

  useEffect(() => {
    getEmployeeSchedules();  // Fetch schedules for the logged-in employee  
  }, [])

  // Example schedule data
  const schedule = [
    { day: 'Monday' },
    { day: 'Tuesday' },
    { day: 'Wednesday' },
    { day: 'Thursday' },
    { day: 'Friday' },
  ];

  const startTime = employeeSch.length > 0 ? employeeSch[0].start : 'Loading...'; // Fallback value if data is not yet available
  const endTime = employeeSch.length > 0 ? employeeSch[0].end : 'Loading...';
  const [timeOffRequests, setTimeOffRequests] = useState([]);
  const [showStartPicker, setShowStartPicker] = useState(false);
  const [showEndPicker, setShowEndPicker] = useState(false);


  // Handle the Start Date Change for both Android and iOS
  const handleStartDateChange = (event, selectedDate) => {
    if (selectedDate) { // Check if a date is selected
      setShowStartPicker(Platform.OS === 'ios'); // iOS picker stays open, Android closes automatically
      setStartDate(selectedDate);
    }
    if (Platform.OS === 'android') {
      setShowStartPicker(false);  // Hide Android picker after selection
    }
  };

  // Handle the End Date Change for both Android and iOS
  const handleEndDateChange = (event, selectedDate) => {
    if (selectedDate) { // Check if a date is selected
      setShowEndPicker(Platform.OS === 'ios');
      setEndDate(selectedDate);
    }
    if (Platform.OS === 'android') {
      setShowEndPicker(false);  // Hide Android picker after selection
    }
  };



  const handleSubmitTimeOff = () => {
    if (!startDate || !endDate || !reason) {
      Alert.alert('Error', 'Please fill in all fields.');
      return;
    }

    axios.post('https://employee-nine-theta.vercel.app/api/employee/requestTimeOff', {
      employeeId,
      startDate: startDate.toISOString().split('T')[0], // Format the date for backend as YYYY-MM-DD
      endDate: endDate.toISOString().split('T')[0],
      reason
    })
      .then(response => {
        Alert.alert('Success', 'Time-off request submitted successfully!');
        setStartDate('');
        setEndDate('');
        setReason('');
        fetchTimeOffRequests();
      })
      .catch(error => {
        Alert.alert('Error', 'Failed to submit time-off request. Please try again.');
        console.error('Error submitting time-off request:', error);
      });
  };



  const fetchTimeOffRequests = async () => {
    try {
      const response = await axios.get(`https://employee-nine-theta.vercel.app/api/employee/timeOffRequests/${employeeId}`);
      setTimeOffRequests(response.data);  // Set the time-off requests in state
    } catch (error) {
      console.error('Error fetching time-off requests:', error);  // Log any errors
    }
  };

  useEffect(() => {
    if (employeeId) {  // Ensure employeeId exists before fetching data
      fetchTimeOffRequests();  // Call the function to fetch time-off requests
    }
  }, [employeeId]);

  const renderRequest = ({ item }) => (
    <View style={{ padding: 10 }}>
      <Text>Start Date: {new Date(item.startDate).toLocaleDateString()}</Text>
      <Text>End Date: {new Date(item.endDate).toLocaleDateString()}</Text>
      <Text>Status: {item.status}</Text>
    </View>
  );



  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerText}>Employee Dashboard</Text>
      </View>

      {/* Tabs */}
      <View style={styles.tabs}>
        <TouchableOpacity
          style={[styles.tabButton, activeTab === 'currentShift' && styles.activeTab]}
          onPress={() => setActiveTab('currentShift')}
        >
          <Text style={styles.tabButtonText}>Current Shift</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tabButton, activeTab === 'schedule' && styles.activeTab]}
          onPress={() => setActiveTab('schedule')}
        >
          <Text style={styles.tabButtonText}>Schedule</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tabButton, activeTab === 'timeOff' && styles.activeTab]}
          onPress={() => setActiveTab('timeOff')}
        >
          <Text style={styles.tabButtonText}>Request Time Off</Text>
        </TouchableOpacity>
      </View>

      <ScrollView>
        {/* Current Shift Tab */}
        {activeTab === 'currentShift' && (
          <View style={styles.container}>
            {/* Current Shift Information */}
            <View style={styles.tabContent}>
              <View style={styles.clockBox}>
                <Text style={styles.clockText}>Current Shift: {startTime} - {endTime}</Text>
                <Text style={styles.clockText}>
                  {isClockedIn ? `Time Since Clock In: ${timeSinceClockIn}` : 'Not Clocked In'}
                </Text>

                {/* Clock In Button */}
                <TouchableOpacity
                  style={[styles.button, styles.clockInButton]}
                  onPress={handleClockIn}
                  disabled={isClockedIn} // Disable button if already clocked in
                >
                  <Text style={styles.buttonText}>Clock In</Text>
                </TouchableOpacity>

                {/* Clock Out Button */}
                <TouchableOpacity
                  style={[styles.button, styles.clockOutButton]}
                  onPress={handleClockOut}
                  disabled={!isClockedIn} // Disable button if not clocked in
                >
                  <Text style={styles.buttonText}>Clock Out</Text>
                </TouchableOpacity>
              </View>

              {/* Total Hours Worked This Week */}
              <View style={styles.hoursWorked}>
                <Text style={styles.hoursWorkedText}>Total Hours Worked</Text>
                <Text style={styles.hoursWorkedValue}>{totalHours.toFixed(2)}</Text>
              </View>
            </View>
          </View>
        )}

        {/* Schedule Tab */}
        {activeTab === 'schedule' && (
          <View style={styles.tabContent}>
            <Text style={styles.scheduleHeader}>Your Schedule</Text>
            {schedule.map((shift, index) => (
              <View key={index} style={styles.scheduleRow}>
                <Text style={styles.scheduleText}>{shift.day}</Text>
                <Text style={styles.scheduleText}>{startTime} - {endTime}</Text>
              </View>
            ))}
          </View>
        )}

        {/* Request Time Off Tab */}
        {activeTab === 'timeOff' && (
          <View style={styles.tabContent}>
            <Text style={styles.formHeader}>Request Time Off</Text>

            {/* Start Date Picker */}
            <TouchableOpacity onPress={() => setShowStartPicker(true)} style={styles.input}>
              <Text>{startDate ? startDate.toISOString().split('T')[0] : 'Select Start Date'}</Text>
            </TouchableOpacity>
            {showStartPicker && (
              <DateTimePicker
                value={startDate || new Date()}  // Fallback to current date if startDate is invalid
                mode="date"
                display={Platform.OS === 'android' ? 'calendar' : 'spinner'}  // Use 'calendar' for Android for a better UI
                onChange={handleStartDateChange}
              />
            )}

            {/* End Date Picker */}
            <TouchableOpacity onPress={() => setShowEndPicker(true)} style={styles.input}>
              <Text>{endDate ? endDate.toISOString().split('T')[0] : 'Select End Date'}</Text>
            </TouchableOpacity>
            {showEndPicker && (
              <DateTimePicker
                value={endDate || new Date()}  // Fallback to current date if endDate is invalid
                mode="date"
                display={Platform.OS === 'android' ? 'calendar' : 'spinner'}
                onChange={handleEndDateChange}
              />
            )}

            {/* Reason for Time Off */}
            <TextInput
              style={styles.textArea}
              placeholder="Reason for time off"
              value={reason}
              onChangeText={setReason}
              multiline={true}
            />

            {/* Submit Button */}
            <TouchableOpacity
              style={styles.submitButton}
              onPress={handleSubmitTimeOff}
            >
              <Text style={styles.buttonText}>Submit Request</Text>
            </TouchableOpacity>

            <FlatList
              data={timeOffRequests}
              renderItem={renderRequest}
              keyExtractor={item => item._id}
            />
          </View>

        )}
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f0f0',
  },
  header: {
    backgroundColor: '#28a745',
    padding: 20,
    alignItems: 'center',
  },
  headerText: {
    fontSize: 24,
    color: 'white',
  },
  tabs: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginVertical: 20,
  },
  tabButton: {
    padding: 10,
    borderRadius: 5,
    backgroundColor: '#007bff',
  },
  activeTab: {
    backgroundColor: '#28a745',
  },
  tabButtonText: {
    color: 'white',
    fontSize: 16,
  },
  tabContent: {
    paddingHorizontal: 20,
    paddingVertical: 10,
  },
  clockBox: {
    alignItems: 'center',
  },
  clockText: {
    fontSize: 18,
    marginVertical: 10,
  },
  button: {
    paddingVertical: 15,
    paddingHorizontal: 30,
    borderRadius: 8,
    marginTop: 10,
  },
  clockInButton: {
    backgroundColor: '#28a745',
  },
  clockOutButton: {
    backgroundColor: '#dc3545',
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
  },
  hoursWorked: {
    marginTop: 20,
    alignItems: 'center',
    backgroundColor: '#007bff',
    padding: 20,
    borderRadius: 8,
  },
  hoursWorkedText: {
    color: 'white',
    fontSize: 18,
  },
  hoursWorkedValue: {
    color: 'white',
    fontSize: 32,
  },
  scheduleHeader: {
    fontSize: 20,
    marginBottom: 10,
  },
  scheduleRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
    padding: 10,
    backgroundColor: 'white',
    borderRadius: 5,
  },
  scheduleText: {
    fontSize: 16,
  },
  formHeader: {
    fontSize: 20,
    marginBottom: 10,
  },
  input: {
    borderColor: '#ccc',
    borderWidth: 1,
    borderRadius: 5,
    padding: 10,
    marginBottom: 10,
  },
  textArea: {
    borderColor: '#ccc',
    borderWidth: 1,
    borderRadius: 5,
    padding: 10,
    height: 100,
    marginBottom: 10,
  },
  submitButton: {
    backgroundColor: '#28a745',
    padding: 15,
    borderRadius: 5,
    alignItems: 'center',
  },
});

export default EmployeeDashboard;
